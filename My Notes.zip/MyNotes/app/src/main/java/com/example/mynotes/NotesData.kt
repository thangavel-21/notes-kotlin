package com.example.mynotes

data class NotesData(var title:String,var description:String, var id: String)
